//
//  ViewController.swift
//  multiPageLayoutLab5
//
//  Created by user256361 on 6/9/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

